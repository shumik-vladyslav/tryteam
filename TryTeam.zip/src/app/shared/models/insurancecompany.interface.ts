// export class InsuranceCompany {
//     public Id: number;
//     public ShortName: string;
//     public FullName: string;
//     public Adress: string;
//     public Phone: string;
//     public Comment: string;
//     public Region: number;
// }