//  import { InsuranceCompany } from "./insurancecompany.interface";
//  import { Office } from "./office.interface";
//  import { Employee, Customer } from "./employee.interface";

// export interface InsurancePolicy {
//     Id: number;
//     Series: string;
//     Number: string;
//     Status: string;
//     Company: InsuranceCompany;
//     ConclusionDate: Date;
//     StartDate: Date;
//     EndDate: Date;
//     Customer: Customer;
//     Employee: Employee;
//     Office: Office;
//     IsChecked: boolean;
// }