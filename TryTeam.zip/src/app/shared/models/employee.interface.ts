// import { Office } from "./office.interface";

// export interface Employee {
//     Id: number;
//     IdentityId: string;
//     //Identity: AppUser;
//     Location: string;
//     Locale: string;
//     Gender: string;
//     Office: Office;
// }
// export interface Customer {
//     Id: number;
//     Name: string;
//     Surname: string;
//     Patronymic: string;
//     Birthday: Date;
//     BirthAdress: string;
//     LivingAdress: string;
//     PaspNum: string;
//     PaspDateReceiving: Date;
//     PaspPlaceReceiving: string;
//     RegistrAdress: string;
//     DrivingLicNum: string;
//     DrivingLicDateReceiving: Date;
//     DrivingLicPlaceReceiving: string;
//     DrivingLicCat: string;
//     Office: Office;
//     Phone: string;
//     Email: string;
//     Notifications: boolean;
// }